#!/bin/bash

node perf/bstr.js
node perf/utf8.js

