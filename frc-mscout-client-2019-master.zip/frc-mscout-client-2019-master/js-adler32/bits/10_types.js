/*::
type ADLER32Type = number;
type ABuf = Array<number> | Buffer | Uint8Array;
*/
