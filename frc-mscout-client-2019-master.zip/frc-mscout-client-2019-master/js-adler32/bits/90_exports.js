// $FlowIgnore
ADLER32.bstr = adler32_bstr;
// $FlowIgnore
ADLER32.buf = adler32_buf;
// $FlowIgnore
ADLER32.str = adler32_str;
