/*::
declare class ADLER32Module {
	bstr(s:string, seed?:ADLER32Type):ADLER32Type;
	buf(b:ABuf, seed?:ADLER32Type):ADLER32Type;
	str(s:string, seed?:ADLER32Type):ADLER32Type;
	version:string;
};
*/
